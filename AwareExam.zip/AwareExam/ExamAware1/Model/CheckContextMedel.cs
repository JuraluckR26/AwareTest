﻿namespace ExamAware1.Model
{
    public class CheckContextMedel
    {
        public string Duplicates { get; set; }

        public string Text { get; set; }

        public string Number {  get; set; }
    }
}
