﻿namespace ExamAware1.Model
{
    public class ResEmployeeModel
    {
        public string Em_Name { get; set; }
        public string Em_Nickname { get; set; }
        public int Em_Age { get; set; }
        public string Em_Position { get; set; }
        public string Em_Phone { get; set; }
    }
}
